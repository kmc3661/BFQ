# Internal BFQ method package
